"""
Nama : Mukhammad Vicky
NIM : 2404853
Kelas : RPL 1 C
"""
panjang = 80
lebar = 32
keliling = 2*(panjang + lebar)
totalJarakMeter = keliling*9
konversiKilometer = float(totalJarakMeter/1000)
print(f"Total jarak yang ditempuh oleh bu Rinda adalah {konversiKilometer} km")