"""
Nama : Mukhammad Vicky
NIM : 2404853
Kelas : RPL 1 C
"""
menit = 10
detik = 48
menitKeDetik = menit*60
konversi = menitKeDetik + 48
print(f"Waktu kecepatan mobil melanju dalam satu putaran adalah {menit} menit {detik} detik\natau total {konversi} detik")