"""
Nama : Mukhammad Vicky
NIM : 2404853
Kelas : RPL 1 C
"""
print("Halo Bu Novia ! Ini adalah program untuk mengetahui nilai siswa sesuai dengan nomor urutnya !")
nilaiSiswa = (90, 86, 57, 59, 95, 77, 67, 94, 82, 86)
urutSiswa = int(input("Masukan nomor urut siswa : "))
nilaiSiswaUrut = nilaiSiswa[urutSiswa]
print(f"Nilai siswa nomor urut {urutSiswa} adalah {nilaiSiswaUrut}")