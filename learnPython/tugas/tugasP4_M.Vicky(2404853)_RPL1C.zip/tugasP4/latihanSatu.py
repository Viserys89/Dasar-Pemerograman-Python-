# Nama : Mukhammad Vicky
# NIM : 2404853
# Kelas : RPL 1 C
daftarAngka = [10, 20, 20, 30, 40, 50, 50, 60]
setDaftarAngka = list(set(daftarAngka))
print(setDaftarAngka)