# Nama : Mukhammad Vicky
# NIM : 2404853
# Kelas : RPL 1 C
mahasiswaList = [88, 75, 63, 97, 82, 74, 91, 80, 81, 63]
print(max(mahasiswaList))
print(min(mahasiswaList))
rataRata = sum(mahasiswaList)/len(mahasiswaList)
print(f"Rata-rata nilai : {rataRata}")
mahasiswaList.sort()
angkaKe2 = mahasiswaList[-2]
print(f"Angka terbesar ke-2 adalah : {angkaKe2}")
