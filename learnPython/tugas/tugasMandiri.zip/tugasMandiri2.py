# Nama : Mukhammad Vicky
# NIM : 2404853
# Kelas : RPL 1 C
Jakarta = (-62088, 106.8456)
Bandung = (-6.9175, 107.6191)
Surabaya = (-7.2575, 112.7521)
kota = [Jakarta, Bandung, Surabaya]
jumlahKota = len(kota)
print(f"Data koordinat untuk kota Bandung adalah {Bandung}")
print(f"Jumlah lokasi yang tersimpan adalah : {jumlahKota}")